# Projeto de Criptografia Matemática em C

**Disciplina:** Algoritmo e Pensamento Computacional  
**Professor:** Francisco de Assis Cavallaro

## Objetivo

Desenvolver um programa em C que integre criptografia simples, matemática aplicada e conceitos computacionais.

## Funcionamento

O sistema utiliza duas camadas:

1. Cifra de Cesar com SHIFT fixo.
2. Deslocamento dinamico por uma sequencia matematica.

Formula:

`deslocamento total = SHIFT + sequencia[i]`

Sequencias disponiveis:

- Progressao Aritmetica (PA)
- Progressao Geometrica (PG)
- Fibonacci
- Numeros Primos

O programa aceita palavras de ate 15 letras, sem acentos ou caracteres especiais.

## Conceitos utilizados

- Variaveis
- Condicionais
- Repeticoes
- Funcoes
- Arrays
- Strings
- ASCII
- Manipulacao de ficheiros
- Menus
- Modularizacao
- Algoritmos matematicos
- Log de execucao

## Arquivos

- `main.c`: menu e fluxo principal.
- `criptografia.c/.h`: algoritmo de criptografia.
- `sequencias.c/.h`: geracao das sequencias.
- `arquivos.c/.h`: gravacao de resultados e logs.

## Compilacao

Com GCC:

```bash
gcc main.c criptografia.c sequencias.c arquivos.c -o criptografia
```

Execucao:

```bash
./criptografia
```

No Windows:

```bash
gcc main.c criptografia.c sequencias.c arquivos.c -o criptografia.exe
```

## Exemplo

Entrada:

- Palavra: `CORACAO`
- SHIFT: `3`
- Sequencia: Fibonacci

Sequencia:

`1, 1, 2, 3, 5, 8, 13`

Resultado:

`GSWGKLE`

O programa cria/atualiza `resultado_criptografia.txt` e adiciona a execucao em `log_execucao.txt`.

## Taxonomia de Bloom

- **Lembrar:** conceitos de ASCII, alfabeto e sequencias.
- **Compreender:** funcionamento da Cifra de Cesar.
- **Aplicar:** implementacao em C.
- **Analisar:** comparacao das sequencias.
- **Avaliar:** analise dos padroes gerados.
- **Criar:** desenvolvimento do sistema integrado.

## Observacao

Este projeto tem finalidade academica. A Cifra de Cesar combinada com sequencias previsiveis nao deve ser considerada uma tecnica de criptografia segura para proteger informacoes reais.
